package Algorithm;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.security.SecureRandom;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.io.File;
import java.io.FileWriter;
import java.util.Random;
import java.math.BigInteger;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import javax.xml.bind.DatatypeConverter;


/**
 *
 * @author rsnyo
 */
public class RC6{

    SecretKey sk;
    public int ks;
    private static int w=32, r=20;
    private static int P32=0xb7e15163, Q32=0x9e3779b9;
    private static int[] SubKey;
    private static int c;
    
      public RC6(){
            
        }
        private static int[]  GenerateSubkeys(byte[] inputKey)
    { 
       int c=inputKey.length/4;
       int[] L = new int[c];
        for (int i = 0; i < L.length; i++)
        {
          L[i] = 0;
        }
        for (int i = 0, j = 0; i < c; i++)
        {
	  L[i] = ((inputKey[j++] & 0xFF)) | ((inputKey[j++] & 0xFF) << 8)| ((inputKey[j++] & 0xFF) << 16) | ((inputKey[j++] & 0xFF) << 24);
        }
	int[] S = new int[2*r+4];	
        S[0]=P32;
        for(int i=1;i<2*r+4;i++)
        {
            S[i] = S[i - 1] + Q32;
        }
            int A=0;
            int B=0;
            int I=0;
            int J =0;
            int v=3*Math.max(c,2*r+4);
            for(int i=0;i<v;i++)
            {
                
            A=S[I]=((S[I]+A+B)<<3)|((S[I]+A+B)>>>29);
            int x=A+B;
            B=L[J]=((L[J]+A + B)<<x)|((L[J]+A + B)>>>32-x);
            I =( I + 1)%(2*r + 4) ;
            J =( J + 1)%c;
            }
        
        return S;
    }     
        
     private static byte[] GenerateEncryptionBlocks(byte[] plaintext,byte[] key)
    {
       
      byte[] CompleteBlock=new byte[16];
      SubKey = GenerateSubkeys(key);
      
      int[] dataBlock= new int[plaintext.length/4];
     
      int registerA,registerB,registerC,registerD; 

      //fill array initially to all zero
      for(int i=0;i<dataBlock.length;i++)
       dataBlock[i]=0;
     
      int index=0;
      for(int i=0;i<dataBlock.length;i++)
      {
      dataBlock[i] =(plaintext[index++] & 0xFF)| ((plaintext[index++]& 0xFF)<<8) | ((plaintext[index++]& 0xFF)<<16)|((plaintext[index++]& 0xFF)<<24);
      }
      registerA = dataBlock[0];
      registerB = dataBlock[1];
      registerC=  dataBlock[2];
      registerD = dataBlock[3];
      
                registerB = registerB + SubKey[0];
		registerD = registerD + SubKey[1];
		for(int i = 1;i<=r;i++){
                    //log 32=5
                    
		     int resultLeftRotate_B =((registerB*(2*registerB+1))<<5) |((registerB*(2*registerB+1))>>>27);
	             int resultLeftRotate_D = ((registerD*(2*registerD+1))<<5)| ((registerD*(2*registerD+1))>>>27);
		     registerA = (((registerA^resultLeftRotate_B)<<resultLeftRotate_D)|((registerA^resultLeftRotate_B)>>>32-resultLeftRotate_D)) + SubKey[2*i];
		     registerC = (((registerC^resultLeftRotate_D)<<resultLeftRotate_B)|((registerC^resultLeftRotate_D)>>>32-resultLeftRotate_B)) + SubKey[2*i+1];
			
	                int swap = registerA;
			registerA = registerB;
			registerB = registerC;
			registerC = registerD;
			registerD = swap;
		}
		registerA = registerA + SubKey[2*r+2];
		registerC = registerC + SubKey[2*r+3];
		
		dataBlock[0] = registerA;
                dataBlock[1] = registerB;
                dataBlock[2] = registerC;
                dataBlock[3] = registerD;
		
		for(int i = 0;i<CompleteBlock.length;i++){
			CompleteBlock[i] = (byte)((dataBlock[i/4] >>> (i%4)*8) & 0xff);
		}
		
		return CompleteBlock;
    }
         
     private static byte[] GenerateDecryptionBlock(byte[] cipherText,byte[] key)
    {   
         
      byte[] CompleteBlock=new byte[16];
      
      SubKey = GenerateSubkeys(key);
      
      int[] dataBlock= new int[cipherText.length/4];
     
      int registerA,registerB,registerC,registerD; 

      //fill array initially to all zero
      for(int i=0;i<dataBlock.length;i++)
       dataBlock[i]=0;
     
      int index=0;
      for(int i=0;i<dataBlock.length;i++)
      {
      dataBlock[i] =(cipherText[index++]& 0xff)|((cipherText[index++]& 0xff)<<8)|((cipherText[index++]& 0xff)<<16)|((cipherText[index++]&0xff)<<24);
      }
      registerA = dataBlock[0];
      registerB = dataBlock[1];
      registerC=  dataBlock[2];
      registerD = dataBlock[3];
      
                registerC = registerC - SubKey[2*r+3];
		registerA = registerA - SubKey[2*r+2];
		for(int i = r;i>=1;i--){
                    //log 32=5
                    //f (A;B;C;D)=(D;A;B;C)
                    int swap = registerD;
                    registerD = registerC;
                    registerC = registerB;
                    registerB = registerA;
	            registerA = swap;
			
		    
	             int resultLeftRotate_D = ((registerD*(2*registerD+1))<<5)|((registerD*(2*registerD+1))>>>27);
                     int resultLeftRotate_B  =((registerB*(2*registerB+1))<<5)|((registerB*(2*registerB+1))>>>27);
		     registerC= (((registerC - SubKey[2*i+1])>>>resultLeftRotate_B)|((registerC - SubKey[2*i+1])<<32-resultLeftRotate_B))^ resultLeftRotate_D ;
		     registerA = (((registerA-SubKey[2*i])>>>resultLeftRotate_D)|((registerA-SubKey[2*i])<<32-resultLeftRotate_D))^ resultLeftRotate_B;
	                
		}
		registerD = registerD - SubKey[1];
		registerB = registerB - SubKey[0];
		
		dataBlock[0] = registerA;
                dataBlock[1] = registerB;
                dataBlock[2] = registerC;
                dataBlock[3] = registerD;
		
		for(int i = 0;i<CompleteBlock.length;i++){
			CompleteBlock[i] = (byte)((dataBlock[i/4] >>> (i%4)*8) & 0xff);
		}
		
		return CompleteBlock;
    }
    
    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    public void genrateKey(String key) throws Exception {
        SecureRandom sr = new SecureRandom(key.getBytes());
        KeyGenerator kg = KeyGenerator.getInstance("RC6");
        kg.init(ks, sr);
        sk = kg.generateKey();
    }

    public byte[] encrypt(byte[] b) throws Exception {

        Cipher cipher = Cipher.getInstance("RC6");
        cipher.init(Cipher.ENCRYPT_MODE, sk);
        byte[] encrypted = cipher.doFinal(b);
        return encrypted;
    }

    public byte[] decrypt(byte[] toDecrypt) throws Exception {

        Cipher cipher = Cipher.getInstance("RC6");
        cipher.init(Cipher.DECRYPT_MODE, sk);
        byte[] decrypted = cipher.doFinal(toDecrypt);
        return decrypted;
    }

    public void setKeysize(int KS) {
        ks = KS;
    }

}
